//-------------------------------------------------------------
// Lab 4: Selection Statements/ Rnadom Numbers
// Question 2 for CPSC 1155 Lab 4
//
// Author: Jay Seung Yeon Lee  	 	 	 	Date: 2021 - 01 - 27
//-------------------------------------------------------------


#include <iostream>
#include <cmath>
using namespace std;

int main(){

double price;

cout << "What is the price? Enter :";
cin >> price;
if(price > 10){
    price = price -3.14;
}else if(price < 10){
    price = price - 1;
}
cout << "Discounted price: " << price << endl;


int x = 5.2 , y=4;




}