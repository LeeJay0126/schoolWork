//------------------------------------------------------------- 
// Lab 1: Getting Started with C++ 
// printHello.cpp: The program prints Hello World! then Hello Again. 
// 
	// Author: Jay Seung Yeon Lee 	 	 	 	Date: 2021 - 01 - 07
//------------------------------------------------------------- 
#include <iostream> using namespace std; 
int main() {
	// This program outputs 2 messages cout << "Hello World!" << endl; cout << "Hello Again." << endl; 

	return 0;  	 	 	// Return to OS and indicate no errors 
} // End main 

