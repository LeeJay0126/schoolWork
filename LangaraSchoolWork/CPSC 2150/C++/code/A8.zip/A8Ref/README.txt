

1. Could not get cycle function to fully work
2. Could not get Pathlength to work 
3. Could not run solver -batch <cmds.txt> output.txt