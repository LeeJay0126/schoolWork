

Commented out the following 6 tests that involves "SpecialCaseEmptyList".

includes:

isEmptyTest- SpecialCaseEmptyList
lengthTest- SpecialCaseEmptyList
equalsTest- SpecialCaseEmptyList
notequalsTest- SpecialCaseEmptyList
copyConstructorTest- SpecialCaseEmptyList
destructorTest- SpecialCaseEmptyList