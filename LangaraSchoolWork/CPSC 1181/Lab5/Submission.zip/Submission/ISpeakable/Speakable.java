package ISpeakable;

public interface Speakable {
    void speak();

}
