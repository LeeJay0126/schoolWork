import java.util.ArrayList;

public class Q2 {
    public static void main(String[] args){
        ArrayList<Integer> a= new ArrayList<Integer>();
        ArrayList<Integer> b= new ArrayList<Integer>();
        a.add(1);
        a.add(2);
        a.add(3);
        b.add(4);
        b.add(5);
        b.add(6);
        add(a,b);
       
      // System.out.println(a);
    }

    public static void add(ArrayList<Integer> a, ArrayList<Integer> b) {
        for(int i = 0; i<a.size(); i++)
            a.set(i, (a.get(i)+b.get(i)));
     
     }
}