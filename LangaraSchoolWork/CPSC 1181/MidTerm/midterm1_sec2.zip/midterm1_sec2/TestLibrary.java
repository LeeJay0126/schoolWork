import java.util.ArrayList;
public class TestLibrary{
  public static void main(String[] args){
    Library library = new Library();
    library.addReservedBook("Calculus","Math");
    library.addReservedBook("physics 12","physics");
    library.addReservedBook("Big Java: Early Objects","java");
    library.addReservedBook("Clean code","java");
    library.addReservedBook("English 12","language");
    library.changeSubject(4,"algorithm");
    System.out.println(library);
  }
}

//----
class Book{
  // Add instance variables, methods, and override toString() method
  private String title;
  private String subject;
  public Book(String title, String subject){
    this.title = title;
    this.subject = subject;
  }
  public String getTitle(){
    return title;
  }
  public void setSubject(String subject){
    this.subject = subject;
  }
  public String toString(){
    return "title: "+title+", subject: "+subject+"";
  }
  

}

//----
class ReservedBook{
  // Add instance variables, methods, and override toString() method
    private int id;
    private Book book;
    private static int count=1;
    public ReservedBook(String title, String subject){
      book = new Book(title, subject);
      id = count++;
    }
    public String getTitle(){
      return book.getTitle();
    }
    public int getId(){
      return id;
    }
    public void setSubject(String subject){
      book.setSubject(subject);
    }

  public String toString(){
    return "["+book.toString()+", id: "+id+"]";
  }
  

}

//----
class Library{
  private ArrayList<ReservedBook> list;

	public Library(){
    list = new ArrayList<ReservedBook>();
  }

	public void addReservedBook(String title, String subject){
    title = title.substring(0,1).toUpperCase() + title.substring(1).toLowerCase(); //2
    subject = subject.toLowerCase(); //1
    insert(title,subject); //6

	}

  private void insert(String title, String subject){
    int i=0;
    for( ; i<list.size(); i++){
      if(title.compareTo(list.get(i).getTitle())<0){
        break;
      }
    }
    list.add(i,new ReservedBook(title, subject));
  }

	public boolean changeSubject(int id, String subject){
    subject = subject.toLowerCase();
    for(ReservedBook b: list){
      if(b.getId()==id)
        b.setSubject(subject);
        return true;
    }
    return false;

	}

  public String toString(){
    return list.toString();
  }

}
