
public class Q1{
    public static void main(String[] args){
    String s1 = new String("hello");
    String s2 = "java" + " AWT";
    String s3 = s2.substring(4);
    String s4 = s1+s3.toUpperCase();
    String s5 = s4 + " JavaFX";
    
    s1=s4;
    s1=null;
    s3=s4;

    }
}

Note that in this case Java Compiler efficiency for immutable objects will not work, since they are output of some process. 
However, if you assumed that there will be only one instance of " AWT", then you got the mark
Nine Strings or Seven String, both got full markd
s1="hello"
"java"
" AWT"
s2="java AWT"
s3=" AWT"
" AWT"
s4="hello AWT"
"javaFX"
s5="hello AWT JavaFX"
 
Part B: 6 objects claimed by garbage collector
"hello" necome garbage
"java"
" AWT"
s2="java AWT"
" AWT" become garbage
" AWT"
s4="hello AWT"
"javaFX"
s5="hello AWT JavaFX"

 
