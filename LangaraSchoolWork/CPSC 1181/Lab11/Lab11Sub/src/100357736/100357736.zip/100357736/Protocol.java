public interface Protocol {
    int ADD_ITEM = 0;
    int CHECK_INVENTORY = 1;
    int TAKE_ITEM = 2;
    int GET_THRESHHOLD = 3;
    int QUIT = 4;
    int SUCCEED = 5;
    int FAILED = 6;
    int CLOSED = 7;
    int PORT = 24444;
}
