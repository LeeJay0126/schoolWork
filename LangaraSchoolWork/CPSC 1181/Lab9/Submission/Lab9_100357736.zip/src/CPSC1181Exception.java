/**
 * public class CPSC1181Exception
 *
 *   Referred from Lab9.zip from lab notes
 *
 */
public class CPSC1181Exception extends Exception{
        public CPSC1181Exception() {
    }

    /**
     * Just used a super class from Exception CPSC1181Exception class extends from
     * @param var1
     */
    public CPSC1181Exception(String var1) {
        super(var1);
    }
}
