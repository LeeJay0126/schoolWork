package cpsc2350.hw3;

public enum RegistrationResult {
    ENROLLED,
    WAIT_LISTED,
    SCHEDULE_CONFLICT,
    PREREQUISITE_NOT_MET,
    COURSE_FULL,
    COURSE_CLOSED
}