const tasks = [
    {
        id: 1,
        taskName: 'Go for bike ride on Saturday',
        completed: false,
        important: false
    },
    {
        id: 2,
        taskName: 'Finish laundry by Sunday afternoon',
        completed: false,
        important: true
    },
    {
        id: 3,
        taskName: 'Bake chocolate brownies on Friday',
        completed: true,
        important: true
    },
]

module.exports = tasks;