function ToggleButton(props) {

    return (
        <div>
            <label class="switch">
                <input type="checkbox" onChange={props.onSwitchHandler}></input>
                <span class="slider"></span>
            </label>
        </div> 
    );

}

export default ToggleButton;