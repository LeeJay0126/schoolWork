
function About () {
    return (
        <h1>About this page</h1>
    );
}

export default About;