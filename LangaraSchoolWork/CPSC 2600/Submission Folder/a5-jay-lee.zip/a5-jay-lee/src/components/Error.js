
function Error() {
    return (
        <h1>Oops!Page Not Found!</h1>
    );
}

export default Error;