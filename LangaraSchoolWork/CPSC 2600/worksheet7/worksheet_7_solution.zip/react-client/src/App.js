import HTTPRoutes from './HTTPRoutes';

function App() {

  return (
    <div className="App">
      <HTTPRoutes key={0} requestType='GET'/>
      <HTTPRoutes key={1} requestType='GETBYID'/>
      <HTTPRoutes key={2} requestType='POST'/>
    </div>
  );
}

export default App;
