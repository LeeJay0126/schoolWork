import axios from 'axios'
import { useState } from 'react'

function HTTPRoutes(props) {
    const API_endpoint = 'http://localhost:3500/api/tasks/'
    // Destruture the request type from props
    const type = props.requestType
    // useState hook to keep track of the final result from API endpoint
    const [result, setResult] = useState('')
    // useState hook to keep track of user input from textbox
    const [input, setInput] = useState('')
    
    /**
     * This is where you make the appropriate HTTP requests to the server.
     */
    async function sendRequest() {
        /**
         * @type GET
         * 1. Make a GET request to get all list of tasks from server
         * 2. Map through the data array from the response
         * 3. Use the setResult function to store each task as an <li>
         */
        if (type === 'GET') {
            try {
                const res = await axios.get(API_endpoint);
                setResult(res.data.map( (task, index) => { 
                    return (<li key={index}>{task.taskName}</li>) 
                }))
            } catch(e) {
                setResult('Error: An invalid request has been made')
            }
        } 
        /**
         * @type GET BY ID
         * 1. Make a GET request to get the task by its ID
         * 2. Note that the input is stored in state (look at the useState hook declared at the top and how it is used in the return statement)
         * 3. Use the setResult function to store the task in state.
         */
        else if (type === 'GETBYID') {
            try {
                // @todo Make a GET/:id request to API and store the specific task in state
                const res = await axios.get(API_endpoint+input);
                setResult(`
                        completed: ${res.data[0].completed}, 
                        id: ${res.data[0].id}, 
                        important: ${res.data[0].important}, 
                        task name: ${res.data[0].taskName}
                `)
            } catch(e) {
                setResult('Error: An invalid request has been made')
            }
        /**
         * @type POST
         * 1. Make a POST request to create a new task
         * 2. Remember to send the taskName as part of the body of the request.
         * 3. Use the setResult function to store the task in state.
         */
         } else if (type === 'POST') {
            try {
                // @todo Make a POST request to API and pass the taskName as part of the body
                await axios.post(API_endpoint, {taskName: input})
                // Update state to match demo video
                setResult(`New task ${input} added. Make a GET request to retreive new list of tasks`)
            } catch(e) {
                setResult('Error: An invalid request has been made')
            }
            
        } else {
            console.log('Something else went wrong')
        }
    }

    return (
        <main>
            {type === 'GET' ? 
            (
                <>
                    <h2>{type} HTTP Request</h2>
                    <div>Result from server:
                        <ul>
                            {result}
                        </ul>
                    </div>
                    <button onClick={() => sendRequest()}>Get list of tasks</button>
                </>
            ) : 
            (
                <>
                    <h2>{type} HTTP Request</h2>
                    <div>Result from server:<p>{result}</p></div>
                    <input type='text' onChange={field => setInput(field.target.value)} />
                    <button onClick={() => sendRequest()}>Submit</button>
                </>
            )}
            
        </main>
    )
}

export default HTTPRoutes;