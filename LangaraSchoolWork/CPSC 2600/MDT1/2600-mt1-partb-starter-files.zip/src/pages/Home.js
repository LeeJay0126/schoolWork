import React, { useEffect, useState } from 'react';
import ImgGallery from '../components/ImgGallery';

function Home() {
  const [appState, setAppState] = useState({
    loading: false,
    images: null,
  });

  useEffect( () => {
    const staticGallery = [
      {
          "albumId": 1,
          "id": 1,
          "title": "Placeholder Title 1",
          "url": "https://via.placeholder.com/600/56acb2",
          "thumbnailUrl": "https://via.placeholder.com/150/56acb2"
      },
      {
        "albumId": 1,
        "id": 2,
        "title": "Placeholder Title 2",
        "url": "https://via.placeholder.com/600/8985dc",
        "thumbnailUrl": "https://via.placeholder.com/150/8985dc"
      },
      {
        "albumId": 1,
        "id": 3,
        "title": "Placeholder Title 3",
        "url": "https://via.placeholder.com/600/5e12c6",
        "thumbnailUrl": "https://via.placeholder.com/150/5e12c6"
      },
    ]

    setAppState({ loading: true });
    setAppState({ loading: false, images: staticGallery} );
  }, [setAppState]);

  return (
      <ImgGallery isLoading={appState.loading} images={appState.images}/>
  );

}
export default Home;
