import React from 'react'

const ImgCard = (props) => {
    const { item } = props;
    return (
              <div className="col s12 m4">
                <div className="card medium">
                  <div className="card-image">
                    <img alt={item.title} src={item.thumbnailUrl}/>
                    <span className="card-title">Replace with API data</span>
                  </div>
                  <div className="card-content">
                    <h6>Album ID: Replace with API data</h6>
                    <h6>ID: Replace with API data</h6>
                  </div>
                  <div className="card-action">
                    <a href={item.url}>Image URL</a>
                  </div>
                </div>
              </div>
    )
}

export default ImgCard
