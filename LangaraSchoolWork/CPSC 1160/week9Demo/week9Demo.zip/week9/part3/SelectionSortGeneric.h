#ifndef SEL_SORT_GENERIC_H
#define SEL_SORT_GENERIC_H

template<typename T>
class SortGeneric {
    public:
        void sort(T list[], int listSize) ;
        
    private:
};

#endif
