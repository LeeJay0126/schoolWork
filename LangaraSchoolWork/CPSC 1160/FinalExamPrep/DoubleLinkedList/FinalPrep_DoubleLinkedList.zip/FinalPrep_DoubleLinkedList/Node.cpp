#include "Node.h"
#include <iostream>
#include <string>
using namespace std;

void Node::insertAfter(Node* prev_node, int data){
    if(prev_node == NULL){
        cout << "previous node cannot be null";
        return;
    }
    
    Node * newNode = new Node;
    newNode->data = data;
    newNode->next = prev_node->next;
    
}