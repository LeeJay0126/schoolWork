#ifndef NODE_H
#define NODE_H
#include <string>
using namespace std;

class Node{
    
    public:
        void insertFront(Node** head, int data);
        void insertAfter(Node* prev_node, int data);
        void insertEnd(Node** head, int data);
        void deleteNode(Node** head, Node* del_node);
        void displayList(Node* node);
    private:
        Node *next;
        Node *previous;
        int data;
    
    
    
}