#ifndef SWAPLIB_H
#define SWAPLIB_H
#include <string>
using namespace std;

class SwapUtil{

    public:
        void swap(int *, int *);
        void swap(string *, string *);
        void swap(double *, double *);
};


#endif