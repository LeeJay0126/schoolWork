// filename: MyStruct.h

#ifndef MYSTRUCT_H
#define MYSTRUCT_H

#include <string>
using namespace std;

struct MyData 
{
  int id;
  string codeName;
} ; 


#endif
