#include "Rectangle_100357736.h"
#include <iostream>
using namespace std;

void Rectangle::setWidth(double w){
    width  = w;
}

void Rectangle::setHeight(double h){
    height = h;
}

Rectangle::Rectangle(){
    width = 1;
    height = 1;
}

Rectangle::Rectangle(double w, double h){
    width = w;
    height = h;
}

double Rectangle::getArea(){
    double area = width * height;
    return area;
}

double Rectangle::getPerimeter(){
    double perimeter = width*2 + height*2;
    return perimeter;
}

double Rectangle::getHeight(){
    return height;
}

double Rectangle::getWidth(){
    return width;
}

