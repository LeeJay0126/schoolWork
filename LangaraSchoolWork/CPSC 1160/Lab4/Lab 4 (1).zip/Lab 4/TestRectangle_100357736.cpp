#include "Rectangle_100357736.h"
#include <iostream>
using namespace std;

int main(){
    //Assign width 4 and height 40
    
    Rectangle r1(4,40);
    Rectangle r2(3.5,35.9);
    
    double area1 = r1.getArea();
    double area2 = r2.getArea();
    double per1 = r1.getPerimeter();
    double per2 = r2.getPerimeter();
    
    double wid1 = r1.getWidth();
    double hei1 = r1.getHeight();
    double wid2 = r2.getWidth();
    double hei2 = r2.getHeight();
    
    cout << "First rectangle's width is : " << wid1 << " and height is : " << hei1 << ". Perimeter : " << per1 << " and Area : " << area1 << endl;
    cout << "Second rectangle's width is : " << wid2 << " and height is : " << hei2 << ". Perimeter : " << per2 << " and Area : " << area2 << endl;
    
    return 0;
}