#ifndef RECTANGLE_100357736_H
#define RECTANGLE_100357736_H

class Rectangle {
    public:
        Rectangle();
        Rectangle(double nwidth, double nheight);
        
        //setters
        void setWidth(double w);
        void setHeight(double h);
        
        //getters
        double getWidth();
        double getHeight();
        
        double getArea();
        double getPerimeter();
        
    private:
        double width;
        double height;
        
};

#endif


