function createUseString(id, x, y) {
   //create a function that generates a use tag
   //that uses the id, and transform the tag by x and y
   //remember to return the string
   
}

//Use this function to generate numbers between
//the minimum and maximum values, in the createMultipleTags 
//function.
function randomNumber(minNum, maxNum){
   return minNum + (maxNum-minNum)*Math.random();
}
function createMultipleTags(id, n, minX, maxX, minY, maxY) {
   //create a function the generates as string
   //That represents n use tags for the id, and at
   //random locations, between the bounding box
   //defined by minX, maxX, minY, maxY
   //use the randomNumber function to generate a single 
   //number between a given range.

   //remember to return the string

}
function generateFish(event) {
   //Using the #numFishes input from the html page
   //generate that many Fishes  within the blue area
   //of the drawing.  
   //Use the functions you've written above to create the tags.
   //Then insert them into the #animals group.

}

function generatePlant(event) {
   //Using the #numPlants input from the html page
   //generate that many Plant  within the blue area
   //of the drawing.  
   //Use the functions you've written above to create the tags.
   //Then insert them into the #plants group.

}