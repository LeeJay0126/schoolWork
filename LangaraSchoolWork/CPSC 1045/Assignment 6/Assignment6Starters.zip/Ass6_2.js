function distance(x1,x2,y1,y2){
   //Using pythagoras equation
   //write the function to return the distance between two points

}
function calculateScore(dist){
   //use this function to help determine the score 
   //of the arrow. The function should return either 0,5,10,15,20 based on dist input value.
   //dist represents the distance.

}

//optional
function createArrowTag(x,y){
   //You can optionally make a createArrowTag function
   //to simplify your code, or if you want to make fancier arrows.
 
}
//Helper function for generating random numbers.
function randomNumber(minNum, maxNum){
   return minNum + (maxNum-minNum)*Math.random();
}

//Because we haven't introduced objects yet, all the work will go into
//The event listener for now. But there are better ways to structure this code.
function fireArrows(event){
   //Hint: You will can to generate arrows, and calculate the score within the same loop
   //As with the previous part, it is better to generate the tags for multipe arrows as a string
   //and then insert the string into #ammunition group after the loop.
   //Use your calculateScore function to help with the scoring
   
}
