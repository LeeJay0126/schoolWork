//Please write the event listener and two helper functions here
//helper function 1: determines the next color based on the current color
//helper function 2: determines if all the colors are identical
//use the helper functions in the event listener

