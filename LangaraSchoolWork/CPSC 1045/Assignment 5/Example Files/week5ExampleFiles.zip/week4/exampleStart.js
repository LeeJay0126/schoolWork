function calculate(){
   console.log("Please write some code");
}