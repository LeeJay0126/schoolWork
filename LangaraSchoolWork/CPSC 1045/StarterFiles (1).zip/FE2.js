function analyze(event){


}