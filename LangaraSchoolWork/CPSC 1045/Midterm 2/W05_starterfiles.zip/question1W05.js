/*Remember that array indexes in computer science starts from 0 */
/*While humnan language usually starts indexes at 1 */

function verify() {

}