<?php
// CITRIX CONFIG - this may be different if you're using your own computer.
define('DBHOST', 'localhost');
define('DBNAME', '2030project');
define('DBUSER', 'root');
define('DBPASS', '');
 ?>