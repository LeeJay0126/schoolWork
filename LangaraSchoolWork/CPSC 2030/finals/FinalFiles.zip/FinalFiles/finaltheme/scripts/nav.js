
document.addEventListener('DOMContentLoaded', function() {
	
	const listItems = document.querySelectorAll("main li");
	let nav = document.querySelector("nav ul");

	for (let item of listItems) {
		nav.appendChild(item);
	}
	
	// Insert your code below
	
	
});