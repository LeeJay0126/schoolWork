<?php  ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Final Exam</title>

    <?php wp_head(); ?>
  </head>
  <body>

  <header>
    <h1><?php bloginfo('name'); ?></h1>
  </header>
	<nav>
    <ul>
    </ul>
  </nav>

  <main>