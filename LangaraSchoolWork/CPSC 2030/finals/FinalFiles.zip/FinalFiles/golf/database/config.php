<?php
// MY COMPUTER
define('DBHOST', 'localhost');
define('DBNAME', 'golf');
define('DBUSER', 'root');
define('DBPASS', '');
 ?>
