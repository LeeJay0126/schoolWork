<?php
function validateSelection()
{		
	
}

function validateLogin()
{

}
?>