<!DOCTYPE html>
<html style="">
  <head>
    <meta charset="utf-8">
    <title>Lab6: Hello PHP World!</title>

  </head>
  <body>

    <header>
        <h1>Hello PHP World!</h1>
        <div>
          An Introduction to Server-Side Scripting.
        </div>
    </header>

    <main>

    </main>

  </body>
</html>
