<?php
// CITRIX CONFIG - this may be different if you're using your own computer.
define('DBHOST', 'localhost');
define('DBNAME', 'lab8');
define('DBUSER', 'root');
define('DBPASS', '');
 ?>
