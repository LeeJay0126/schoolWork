<?php
// MY COMPUTER
define('DBHOST', 'localhost');
define('DBNAME', 'mt2');
define('DBUSER', 'root');
define('DBPASS', '');
 ?>
