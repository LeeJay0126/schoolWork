<?php

require 'config.php';

function db_connect() {

}

function submit_post() {
  
}

function get_posts() {

}

?>
