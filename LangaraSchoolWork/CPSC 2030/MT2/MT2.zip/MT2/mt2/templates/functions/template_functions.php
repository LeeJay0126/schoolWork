<?php

function the_inventory() {

 
}

function the_stat() {


} 
?>