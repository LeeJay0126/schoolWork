<?php

// Validate plate number
function validate()
{
    
}

function the_validation_message($type) 
{

}
 ?>
