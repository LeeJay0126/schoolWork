mkdir -p ./script2/antelope/siting
mkdir -p ./script2b/bears/cubs
mkdir -p ./script2b/bears/spray/dangerous
mkdir -p ./script2/antelope/bear/fight
mkdir -p ./script2fg/cat/large/Persian
mkdir -p ./srcipt2f/cat/small/unknown
mkdir -p ./script2g/bears/spray
