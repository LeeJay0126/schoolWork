mkdir script1
cd script1
mkdir kpop
mkdir Jazz
mkdir classical
cd kpop
mkdir BTS
mkdir Twice
cd ..
cd Jazz
mkdir Brubeck
mkdir Seatbelts
cd ..
cd classical
mkdir Mozart
mkdir Beethoven
cd ..
cd ..
cp Directory.png ./script1/kpop/BTS
cp Directory.png ./script1/Jazz/Brubeck
cp Directory.png ./script1/classical