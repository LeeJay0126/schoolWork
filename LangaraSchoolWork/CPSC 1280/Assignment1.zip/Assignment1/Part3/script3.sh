echo 'The number of electrons in a Carbon atom is 6 ' >> result.txt
echo 'ls g*' >> result.txt
echo 'pwd' >> result.txt
echo 'cat g*' >> result.txt
